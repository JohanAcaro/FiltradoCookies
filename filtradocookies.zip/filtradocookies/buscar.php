<?php
$precio_buscado=$_GET["precio"];
//select * from prooductos where nombre=$prenda_buscada
setcookie("precio",$precio_buscado);
$busqueda=$_COOKIE["precio"];
//conexión a base de datos
$conexion=mysqli_connect("localhost","root","","northwind");
//var_dump($conexion);
//consulta 
$consulta="select ProductID,ProductName,UnitPrice from products where UnitPrice<'$busqueda' order by UnitPrice asc";
//ejecutar la consulta
$cursor=$conexion->query($consulta);
//var_dump($cursor);

//mostrar resultado recorriendo el cursor con un bucle
echo "<table>";
echo "<tr><td>ProductID</td><td>ProductName</td><td>UnitPrice</td></tr>";
while($fila=$cursor->fetch_row()){
    //var_dump($fila);
    echo "<tr>";
    echo "<td>".$fila[0]."</td>";
    echo "<td>".$fila[1]."</td>";
    echo "<td>".$fila[2]."</td>";
    echo "</tr>";
}
echo "</table>";
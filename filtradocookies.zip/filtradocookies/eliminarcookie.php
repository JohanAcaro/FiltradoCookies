<?php

if( isset($_COOKIE["precio"]) )
    {
        echo "Eliminamos la Cookie";
        setcookie("precio",$precio_buscado,-1);
        $precio_buscado=1;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo "<h2>Filtrado de cookies</h2>";
    ?>
    <form action="buscar.php" method="get"> 
        <label>Dime un precio</label>
        <input type="number" name="precio">
        <input type="submit" name="Enviar">
    </form>

</body>
</html>
